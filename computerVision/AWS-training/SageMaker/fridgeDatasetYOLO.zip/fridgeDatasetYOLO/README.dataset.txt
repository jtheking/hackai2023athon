# HackAI 2023 > 2023-04-16 1:35am
https://universe.roboflow.com/school-3jgp7/hackai-2023-mtehv

Provided by a Roboflow user
License: Public Domain

